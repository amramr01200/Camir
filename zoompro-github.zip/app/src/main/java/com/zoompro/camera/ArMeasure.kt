package com.zoompro.camera

import android.app.Activity
import android.content.Context
import android.hardware.display.DisplayManager
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.Display
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.google.ar.core.Anchor
import com.google.ar.core.ArCoreApk
import com.google.ar.core.Config
import com.google.ar.core.Coordinates2d
import com.google.ar.core.DepthPoint
import com.google.ar.core.Frame
import com.google.ar.core.HitResult
import com.google.ar.core.Plane
import com.google.ar.core.Session
import com.google.ar.core.TrackingState
import com.google.ar.core.exceptions.CameraNotAvailableException
import kotlinx.coroutines.delay
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ConcurrentLinkedQueue
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.abs
import kotlin.math.sqrt

/** حالة الواجهة (تُكتب من خيط الرسم وتُقرأ من Compose). */
class ArUi {
    var tracking by mutableStateOf(false)
    var startPt by mutableStateOf<Offset?>(null)
    var endPt by mutableStateOf<Offset?>(null)
    var liveCm by mutableStateOf<Float?>(null)
    var hasStart by mutableStateOf(false)
    var result by mutableStateOf<String?>(null)
    var error by mutableStateOf<String?>(null)
}

/** منطق القياس: يعمل على خيط الرسم داخل كل إطار. */
class ArEngine(private val ui: ArUi) {
    @Volatile var kind = 0                 // 0 مسافة بنقطتين، 1 ارتفاع، 2 مشي
    val cmds = ConcurrentLinkedQueue<Int>() // 1 بداية، 2 نهاية، 3 إعادة
    private var anchor: Anchor? = null
    private var startPos: FloatArray? = null
    private var lastEnd: FloatArray? = null

    private fun bestHit(hits: List<HitResult>): HitResult? = hits.firstOrNull { h ->
        val t = h.trackable
        (t is Plane && t.isPoseInPolygon(h.hitPose)) || t is com.google.ar.core.Point || t is DepthPoint
    }

    private fun metric(a: FloatArray, b: FloatArray): Float {
        val dx = b[0] - a[0]; val dy = b[1] - a[1]; val dz = b[2] - a[2]
        return if (kind == 1) abs(dy) else sqrt(dx * dx + dy * dy + dz * dz)
    }

    private fun fmt(m: Float) = "${(m * 100f).toInt()} سم (${"%.2f".format(m)} م)"

    private fun reset() {
        anchor?.detach(); anchor = null
        startPos = null; lastEnd = null
        ui.hasStart = false; ui.result = null
        ui.startPt = null; ui.endPt = null; ui.liveCm = null
    }

    fun process(frame: Frame, w: Int, h: Int) {
        val cam = frame.camera
        if (cam.trackingState != TrackingState.TRACKING) { ui.tracking = false; return }
        ui.tracking = true

        val view = FloatArray(16); val proj = FloatArray(16); val vp = FloatArray(16)
        cam.getViewMatrix(view, 0)
        cam.getProjectionMatrix(proj, 0, 0.05f, 50f)
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0)
        fun project(p: FloatArray): Offset? {
            val o = FloatArray(4)
            Matrix.multiplyMV(o, 0, vp, 0, floatArrayOf(p[0], p[1], p[2], 1f), 0)
            if (o[3] <= 0f) return null
            return Offset((o[0] / o[3] * 0.5f + 0.5f) * w, (1f - (o[1] / o[3] * 0.5f + 0.5f)) * h)
        }

        val walk = kind == 2
        val hit = if (walk) null else bestHit(frame.hitTest(w / 2f, h / 2f))
        val liveWorld: FloatArray? = if (walk) cam.pose.translation else hit?.hitPose?.translation

        while (true) {
            val c = cmds.poll() ?: break
            when (c) {
                1 -> {
                    reset()
                    if (walk) {
                        startPos = cam.pose.translation.copyOf(); ui.hasStart = true
                    } else if (hit != null) {
                        val a = hit.createAnchor()
                        anchor = a
                        startPos = a.pose.translation.copyOf(); ui.hasStart = true
                    }
                }
                2 -> {
                    val s = startPos; val e = liveWorld
                    if (s != null && e != null) {
                        lastEnd = e.copyOf()
                        ui.result = (if (kind == 1) "الارتفاع ≈ " else "المسافة ≈ ") + fmt(metric(s, e))
                    }
                }
                3 -> reset()
            }
        }

        val a = anchor
        val s = if (a != null && a.trackingState == TrackingState.TRACKING) a.pose.translation else startPos
        ui.startPt = if (s != null && !walk) project(s) else null
        val endW = if (ui.result != null) lastEnd else liveWorld
        if (s != null && endW != null) {
            ui.liveCm = if (ui.result == null) metric(s, endW) * 100f else null
            ui.endPt = if (walk) null else project(endW)
        } else {
            ui.liveCm = null; ui.endPt = null
        }
    }
}

private const val VS = "attribute vec4 aPos; attribute vec2 aUv; varying vec2 vUv; void main(){ gl_Position = aPos; vUv = aUv; }"
private const val FS = "#extension GL_OES_EGL_image_external : require\n" +
    "precision mediump float; varying vec2 vUv; uniform samplerExternalOES uTex; " +
    "void main(){ gl_FragColor = texture2D(uTex, vUv); }"

/** يرسم صورة الكاميرا كخلفية ويحدّث جلسة ARCore. */
class ArRenderer(
    private val session: Session,
    private val rotation: () -> Int,
    private val onFrame: (Frame, Int, Int) -> Unit
) : GLSurfaceView.Renderer {
    private var tex = 0
    private var prog = 0
    private var aPos = 0
    private var aUv = 0
    private var uTex = 0
    private var w = 1
    private var h = 1
    private var geomDirty = true
    private val quad = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer()
        .apply { put(floatArrayOf(-1f, -1f, -1f, 1f, 1f, -1f, 1f, 1f)); position(0) }
    private val uv = ByteBuffer.allocateDirect(32).order(ByteOrder.nativeOrder()).asFloatBuffer()

    private fun shader(type: Int, src: String): Int {
        val s = GLES20.glCreateShader(type)
        GLES20.glShaderSource(s, src)
        GLES20.glCompileShader(s)
        return s
    }

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        GLES20.glClearColor(0f, 0f, 0f, 1f)
        val t = IntArray(1)
        GLES20.glGenTextures(1, t, 0)
        tex = t[0]
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_S, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_WRAP_T, GLES20.GL_CLAMP_TO_EDGE)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MIN_FILTER, GLES20.GL_LINEAR)
        GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES20.GL_TEXTURE_MAG_FILTER, GLES20.GL_LINEAR)
        prog = GLES20.glCreateProgram()
        GLES20.glAttachShader(prog, shader(GLES20.GL_VERTEX_SHADER, VS))
        GLES20.glAttachShader(prog, shader(GLES20.GL_FRAGMENT_SHADER, FS))
        GLES20.glLinkProgram(prog)
        aPos = GLES20.glGetAttribLocation(prog, "aPos")
        aUv = GLES20.glGetAttribLocation(prog, "aUv")
        uTex = GLES20.glGetUniformLocation(prog, "uTex")
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        w = width; h = height; geomDirty = true
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT)
        if (geomDirty) { session.setDisplayGeometry(rotation(), w, h); geomDirty = false }
        session.setCameraTextureName(tex)
        val frame = try { session.update() } catch (e: Exception) { return }

        quad.position(0); uv.position(0)
        frame.transformCoordinates2d(
            Coordinates2d.OPENGL_NORMALIZED_DEVICE_COORDINATES, quad, Coordinates2d.TEXTURE_NORMALIZED, uv)
        quad.position(0); uv.position(0)

        GLES20.glDisable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthMask(false)
        GLES20.glUseProgram(prog)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0)
        GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, tex)
        GLES20.glUniform1i(uTex, 0)
        GLES20.glVertexAttribPointer(aPos, 2, GLES20.GL_FLOAT, false, 0, quad)
        GLES20.glVertexAttribPointer(aUv, 2, GLES20.GL_FLOAT, false, 0, uv)
        GLES20.glEnableVertexAttribArray(aPos)
        GLES20.glEnableVertexAttribArray(aUv)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        GLES20.glDisableVertexAttribArray(aPos)
        GLES20.glDisableVertexAttribArray(aUv)
        GLES20.glDepthMask(true)

        try { onFrame(frame, w, h) } catch (e: Exception) { }
    }
}

private fun displayRotation(ctx: Context): Int {
    val dm = ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
    return dm.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: 0
}

@Composable
fun ArMeasureScreen(onExit: () -> Unit) {
    val ctx = LocalContext.current
    var ready by remember { mutableStateOf(false) }
    var status by remember { mutableStateOf<ArCoreApk.Availability?>(null) }

    LaunchedEffect(Unit) {
        delay(700) // نترك CameraX يحرر الكاميرا أولاً
        var a = ArCoreApk.getInstance().checkAvailability(ctx)
        var n = 0
        while (a.isTransient && n < 20) { delay(200); a = ArCoreApk.getInstance().checkAvailability(ctx); n++ }
        status = a
        ready = true
    }

    Box(Modifier.fillMaxSize().background(Color.Black).statusBarsPadding().navigationBarsPadding()) {
        when {
            !ready -> Text("جارٍ التحضير...", color = Color.White, modifier = Modifier.align(Alignment.Center))
            status == ArCoreApk.Availability.SUPPORTED_INSTALLED -> ArSession(onExit)
            status == ArCoreApk.Availability.SUPPORTED_NOT_INSTALLED ||
                status == ArCoreApk.Availability.SUPPORTED_APK_TOO_OLD -> Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("يلزم تثبيت أو تحديث «Google Play Services for AR» ثم الرجوع إلى هنا.",
                    color = Color.White, textAlign = TextAlign.Center)
                Chip("تثبيت / تحديث", true) {
                    try { ArCoreApk.getInstance().requestInstall(ctx as Activity, true) } catch (e: Exception) { }
                }
                Chip("رجوع") { onExit() }
            }
            else -> Column(
                Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("جهازك لا يدعم ARCore. استخدم وضع «بالميل» للقياس.",
                    color = Color.White, textAlign = TextAlign.Center)
                Chip("رجوع", true) { onExit() }
            }
        }
    }
}

@Composable
private fun ArSession(onExit: () -> Unit) {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val ui = remember { ArUi() }
    val engine = remember { ArEngine(ui) }
    val session = remember {
        try {
            Session(ctx).also { s ->
                val cfg = Config(s)
                cfg.planeFindingMode = Config.PlaneFindingMode.HORIZONTAL_AND_VERTICAL
                cfg.focusMode = Config.FocusMode.AUTO
                cfg.updateMode = Config.UpdateMode.LATEST_CAMERA_IMAGE
                if (s.isDepthModeSupported(Config.DepthMode.AUTOMATIC)) cfg.depthMode = Config.DepthMode.AUTOMATIC
                s.configure(cfg)
            }
        } catch (e: Exception) {
            ui.error = "تعذر بدء ARCore: ${e.message}"
            null
        }
    }
    if (session == null) {
        Column(
            Modifier.fillMaxSize().padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(ui.error ?: "تعذر بدء ARCore", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(12.dp))
            Chip("رجوع", true) { onExit() }
        }
        return
    }

    var kind by remember { mutableIntStateOf(0) }
    val glView = remember(session) {
        GLSurfaceView(ctx).apply {
            preserveEGLContextOnPause = true
            setEGLContextClientVersion(2)
            setEGLConfigChooser(8, 8, 8, 8, 16, 0)
            setRenderer(ArRenderer(session, { displayRotation(ctx) }) { f, w, h -> engine.process(f, w, h) })
            renderMode = GLSurfaceView.RENDERMODE_CONTINUOUSLY
            setWillNotDraw(false)
        }
    }

    DisposableEffect(session) {
        val obs = object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                if (event == Lifecycle.Event.ON_RESUME) {
                    try {
                        session.resume()
                        glView.onResume()
                    } catch (e: CameraNotAvailableException) {
                        ui.error = "الكاميرا مشغولة. ارجع وأعد المحاولة."
                    } catch (e: Exception) {
                        ui.error = "خطأ: ${e.message}"
                    }
                } else if (event == Lifecycle.Event.ON_PAUSE) {
                    glView.onPause()
                    session.pause()
                }
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose {
            owner.lifecycle.removeObserver(obs)
            glView.onPause()
            session.close()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(factory = { glView }, modifier = Modifier.fillMaxSize())

        Canvas(Modifier.fillMaxSize()) {
            val c = center
            drawCircle(Color.White, 22f, c, style = Stroke(3f))
            drawCircle(CYAN, 5f, c)
            val s = ui.startPt
            val e = ui.endPt
            if (s != null) drawCircle(CYAN, 14f, s)
            if (s != null && e != null) {
                drawLine(CYAN, s, e, strokeWidth = 5f)
                drawCircle(Color.White, 12f, e)
            }
        }

        Column(Modifier.align(Alignment.TopCenter).padding(top = 8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("رجوع") { onExit() }
                Chip("مسافة", kind == 0) { kind = 0; engine.kind = 0; engine.cmds.add(3) }
                Chip("ارتفاع", kind == 1) { kind = 1; engine.kind = 1; engine.cmds.add(3) }
                Chip("مشي", kind == 2) { kind = 2; engine.kind = 2; engine.cmds.add(3) }
            }
            val cm = ui.liveCm
            if (cm != null) {
                Spacer(Modifier.height(10.dp))
                Text(
                    "${cm.toInt()} سم  (${"%.2f".format(cm / 100f)} م)",
                    color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.glass(16.dp).padding(horizontal = 18.dp, vertical = 8.dp)
                )
            }
        }

        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(16.dp).glass(24.dp).padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val res = ui.result
            val hint = when {
                ui.error != null -> ui.error!!
                res != null -> res
                !ui.tracking -> "حرّك الهاتف ببطء لتتبع المكان (يلزم سطح به تفاصيل وإضاءة جيدة)"
                !ui.hasStart -> when (kind) {
                    0 -> "وجّه المركز إلى نقطة البداية ثم اضغط «ضع البداية»"
                    1 -> "وجّه المركز إلى قاعدة الجسم ثم اضغط «ضع البداية»"
                    else -> "قف عند نقطة البداية ثم اضغط «ابدأ»"
                }
                kind == 2 -> "امشِ في خط مستقيم إلى النهاية ثم اضغط «ثبّت النهاية»"
                kind == 1 -> "ارفع المركز إلى أعلى الجسم ثم اضغط «ثبّت النهاية»"
                else -> "حرّك المركز إلى نقطة النهاية ثم اضغط «ثبّت النهاية»"
            }
            Text(hint, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                if (res != null) {
                    Chip("قياس جديد", true) { engine.cmds.add(3) }
                } else if (!ui.hasStart) {
                    Chip(if (kind == 2) "ابدأ" else "ضع البداية", true) { engine.cmds.add(1) }
                } else {
                    Chip("ثبّت النهاية", true) { engine.cmds.add(2) }
                    Chip("إلغاء") { engine.cmds.add(3) }
                }
            }
        }
    }
}
