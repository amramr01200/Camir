# ZoomPro Camera

كاميرا أندرويد: زوم محسّن، وضع ليلي، فلاتر، قياس بالسنتيمتر، كشف كائنات. تعمل بدون إنترنت.
الجهاز المستهدف: **Infinix Hot 60i (X6728)** · أندرويد 15 · minSdk 29.

## هيكل المستودع
```
├── site/                    صفحة التحميل (GitHub Pages)
│   ├── index.html
│   └── .nojekyll
├── .github/workflows/
│   ├── pages.yml            ينشر الصفحة تلقائياً
│   └── build-apk.yml        يبني APK وينشره في Releases
├── app/ + build.gradle.kts   مشروع أندرويد (المرحلة 1)
├── PROMPT.md                البرومبت الكامل لبناء التطبيق
├── PRIVACY.md
└── README.md
```
المشروع الآن يحتوي المرحلة 1 (كاميرا + زوم + فلاتر). البناء يتم عبر Gradle 8.9 في GitHub Actions، أو افتح المجلد في Android Studio.

## الرفع والنشر (مرة واحدة)
1. أنشئ مستودعاً جديداً على GitHub باسم `zoompro-camera` (عام Public).
2. ارفع كل محتويات هذا المجلد (Add file ثم Upload files، واسحب الملفات مع مجلد `.github`).
3. **Settings ← Pages ← Source: GitHub Actions**.
4. **Settings ← Actions ← General ← Workflow permissions: Read and write**.
5. ستظهر الصفحة على: `https://USERNAME.github.io/zoompro-camera/`

## بناء ونشر الـ APK
1. تأكد أن ملفات المشروع في جذر المستودع (بجانب settings.gradle.kts).
2. أنشئ إصداراً: **Releases ← Draft a new release ← Tag: v1.0.0 ← Publish**.
3. يبني Actions الملف `ZoomPro.apk` ويرفقه بالإصدار، وزر التنزيل في الصفحة يشير إليه تلقائياً.

> ملاحظة: الـ APK الناتج توقيعه debug، وهو مناسب للتثبيت الشخصي. للنشر العام وقّعه بمفتاح release.
