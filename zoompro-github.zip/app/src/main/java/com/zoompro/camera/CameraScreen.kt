package com.zoompro.camera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.roundToInt

private val BG = Color(0xFF0B0A14)
private val PURPLE = Color(0xFF7C4DFF)
private val BLUE = Color(0xFF00B0FF)
private val CYAN = Color(0xFF18FFFF)

private val previewSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .build()

// نلتقط بحوالي 12 ميجابكسل لتفادي نفاد الذاكرة عند تطبيق الفلتر على صورة 50MP
private val captureSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .setResolutionStrategy(
        ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
    ).build()

private fun toast(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
}

private fun newImageValues() = ContentValues().apply {
    put(MediaStore.Images.Media.DISPLAY_NAME,
        "ZoomPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()))
    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZoomPro")
}

private fun saveBitmap(ctx: Context, bmp: Bitmap) {
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues())
        ?: error("MediaStore insert failed")
    ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
}

@Composable
private fun Chip(text: String, selected: Boolean, accent: Color = BLUE, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color.Black else Color.White,
        fontSize = 13.sp,
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(if (selected) accent else Color(0x33FFFFFF))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().background(BG).padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("يحتاج التطبيق إلى إذن الكاميرا ليعمل.", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("منح الإذن") }
        }
        return
    }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val executor = remember { Executors.newSingleThreadExecutor() }

    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var fIdx by remember { mutableIntStateOf(0) }
    var strength by remember { mutableFloatStateOf(1f) }
    var expRange by remember { mutableStateOf(0..0) }
    var exp by remember { mutableFloatStateOf(0.5f) }
    var flash by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(false) }
    var ring by remember { mutableStateOf<Offset?>(null) }

    val capture = remember(lens) { ImageCapture.Builder().setResolutionSelector(captureSelector).build() }

    DisposableEffect(lens) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
                    .also { it.setSurfaceProvider(previewView.surfaceProvider) }
                provider.unbindAll()
                val cam = provider.bindToLifecycle(
                    owner, CameraSelector.Builder().requireLensFacing(lens).build(), preview, capture)
                camera = cam
                maxZoom = (cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtMost(20f)
                zoom = 1f
                val r = cam.cameraInfo.exposureState.exposureCompensationRange
                expRange = r.lower..r.upper
                exp = 0.5f
            } catch (e: Exception) {
                toast(ctx, "تعذر تشغيل الكاميرا: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { if (future.isDone) runCatching { future.get().unbindAll() } }
    }

    fun setZ(v: Float) {
        val z = v.coerceIn(1f, maxZoom)
        zoom = z
        camera?.cameraControl?.setZoomRatio(z)
    }

    fun setExp(f: Float) {
        exp = f
        val span = expRange.last - expRange.first
        if (span > 0) camera?.cameraControl?.setExposureCompensationIndex(expRange.first + (f * span).roundToInt())
    }

    fun shoot() {
        capture.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        val m = FILTERS[fIdx].blended(strength)
        if (m == null || strength <= 0.01f) {
            // بدون فلتر: حفظ مباشر بأعلى جودة
            val opts = ImageCapture.OutputFileOptions.Builder(
                ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues()).build()
            capture.takePicture(opts, executor, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) = toast(ctx, "تم الحفظ")
                override fun onError(e: ImageCaptureException) = toast(ctx, "تعذر الحفظ: ${e.message}")
            })
        } else {
            capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val src = image.toBitmap()
                        val rot = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
                        val upright = Bitmap.createBitmap(src, 0, 0, src.width, src.height, rot, true)
                        if (upright !== src) src.recycle()
                        val out = Bitmap.createBitmap(upright.width, upright.height, Bitmap.Config.ARGB_8888)
                        Canvas(out).drawBitmap(upright, 0f, 0f,
                            Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
                        upright.recycle()
                        saveBitmap(ctx, out)
                        out.recycle()
                        toast(ctx, "تم الحفظ")
                    } catch (e: Throwable) {
                        toast(ctx, "تعذر الحفظ: ${e.message}")
                    } finally {
                        image.close()
                    }
                }
                override fun onError(e: ImageCaptureException) = toast(ctx, "تعذر الالتقاط: ${e.message}")
            })
        }
    }

    LaunchedEffect(ring) { if (ring != null) { delay(900); ring = null } }

    Column(Modifier.fillMaxSize().background(BG).statusBarsPadding().navigationBarsPadding()) {
        Row(
            Modifier.fillMaxWidth().height(48.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Chip(if (flash) "الفلاش: يعمل" else "الفلاش: متوقف", flash, CYAN) { flash = !flash }
            Text("ZoomPro", color = Color.White, fontSize = 18.sp)
            Chip("تبديل الكاميرا", false) {
                lens = if (lens == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            }
        }

        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            AndroidView(
                factory = { previewView },
                modifier = Modifier.fillMaxSize(),
                update = { v ->
                    val m = FILTERS[fIdx].blended(strength)
                    val paint = m?.let { Paint().apply { colorFilter = ColorMatrixColorFilter(it) } }
                    v.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                }
            )
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, g, _ -> if (g != 1f) setZ(zoom * g) }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { o ->
                            val pt = previewView.meteringPointFactory.createPoint(o.x, o.y)
                            camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                            ring = o
                        }
                    }
            )
            ring?.let { p ->
                Box(
                    Modifier
                        .offset { IntOffset((p.x - 30.dp.toPx()).roundToInt(), (p.y - 30.dp.toPx()).roundToInt()) }
                        .size(60.dp).border(2.dp, CYAN, CircleShape)
                )
            }
            Text(
                "%.1fx".format(zoom), color = Color.White, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp)
                    .clip(RoundedCornerShape(12.dp)).background(Color(0x66000000))
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
            if (panel) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0xCC0B0A14)).padding(12.dp)
                ) {
                    if (maxZoom > 1.01f) {
                        Text("الزوم", color = Color.White, fontSize = 12.sp)
                        Slider(value = zoom, onValueChange = { setZ(it) }, valueRange = 1f..maxZoom)
                    }
                    Text("قوة الفلتر", color = Color.White, fontSize = 12.sp)
                    Slider(value = strength, onValueChange = { strength = it })
                    if (expRange.last > expRange.first) {
                        Text("السطوع (التعريض)", color = Color.White, fontSize = 12.sp)
                        Slider(value = exp, onValueChange = { setExp(it) })
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        Row(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            (listOf(1f, 2f, 3f, 5f, 10f).filter { it <= maxZoom }).forEach { z ->
                Chip("${z.toInt()}x", abs(zoom - z) < 0.05f) { setZ(z) }
            }
        }
        LazyRow(
            Modifier.fillMaxWidth().padding(vertical = 6.dp),
            contentPadding = PaddingValues(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(FILTERS.size) { i ->
                Chip(FILTERS[i].name, fIdx == i, if (FILTERS[i].night) PURPLE else BLUE) { fIdx = i }
            }
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Chip(if (panel) "إخفاء الضبط" else "ضبط", panel, CYAN) { panel = !panel }
            Box(
                Modifier.size(72.dp).border(4.dp, Color.White, CircleShape).padding(7.dp)
                    .clip(CircleShape).background(Color.White).clickable { shoot() }
            )
            Spacer(Modifier.width(72.dp))
        }
    }
}
