package com.zoompro.camera

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val BG0 = Color(0xFF0B0A14)
val BG1 = Color(0xFF1B1245)
val PURPLE = Color(0xFF7C4DFF)
val BLUE = Color(0xFF00B0FF)
val CYAN = Color(0xFF18FFFF)

val BRAND = Brush.horizontalGradient(listOf(PURPLE, BLUE, CYAN))
private val SELECT = Brush.horizontalGradient(listOf(PURPLE, BLUE))
private val SELECT_NIGHT = Brush.horizontalGradient(listOf(Color(0xFF5B2FD0), Color(0xFF2B1A7A)))

/** تأثير زجاجي: خلفية شفافة متدرجة + حد خفيف. */
fun Modifier.glass(radius: Dp = 20.dp): Modifier {
    val s = RoundedCornerShape(radius)
    return this.clip(s)
        .background(Brush.verticalGradient(listOf(Color(0x40FFFFFF), Color(0x14FFFFFF))), s)
        .border(1.dp, Color(0x40FFFFFF), s)
}

@Composable
fun Chip(text: String, selected: Boolean = false, night: Boolean = false, onClick: () -> Unit) {
    val base = if (selected) {
        Modifier.clip(RoundedCornerShape(20.dp)).background(if (night) SELECT_NIGHT else SELECT)
    } else Modifier.glass()
    Text(
        text, color = Color.White, fontSize = 13.sp,
        modifier = base.clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 7.dp)
    )
}

@Composable
fun ShutterButton(busy: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(78.dp).alpha(if (busy) 0.45f else 1f)
            .border(4.dp, Brush.sweepGradient(listOf(PURPLE, BLUE, CYAN, PURPLE)), CircleShape)
            .padding(8.dp).clip(CircleShape).background(Color.White)
            .clickable(enabled = !busy, onClick = onClick)
    )
}
