package com.zoompro.camera

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.asin
import kotlin.math.roundToInt
import kotlin.math.sqrt
import kotlin.math.tan

/** زاوية ميل الكاميرا تحت الأفق بالدرجات (موجب = لأسفل)، مع تنعيم. */
@Composable
fun rememberTilt(active: Boolean): MutableFloatState {
    val ctx = LocalContext.current
    val tilt = remember { mutableFloatStateOf(0f) }
    DisposableEffect(active) {
        val sm = ctx.getSystemService(Context.SENSOR_SERVICE) as SensorManager
        val sensor = sm.getDefaultSensor(Sensor.TYPE_GRAVITY) ?: sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val l = object : SensorEventListener {
            override fun onSensorChanged(e: SensorEvent) {
                val x = e.values[0]; val y = e.values[1]; val z = e.values[2]
                val g = sqrt(x * x + y * y + z * z)
                if (g < 1f) return
                val deg = Math.toDegrees(asin((z / g).coerceIn(-1f, 1f).toDouble())).toFloat()
                tilt.floatValue += (deg - tilt.floatValue) * 0.12f
            }
            override fun onAccuracyChanged(s: Sensor?, a: Int) {}
        }
        if (active && sensor != null) sm.registerListener(l, sensor, SensorManager.SENSOR_DELAY_GAME)
        onDispose { sm.unregisterListener(l) }
    }
    return tilt
}

@Composable
fun MeasurePanel(tilt: Float, camH: Int, onCamH: (Int) -> Unit) {
    var kind by remember { mutableIntStateOf(0) }       // 0 مسافة، 1 ارتفاع، 2 معايرة
    var step by remember { mutableIntStateOf(0) }
    var knownD by remember { mutableIntStateOf(200) }
    var baseDist by remember { mutableFloatStateOf(0f) }
    var result by remember { mutableStateOf<String?>(null) }

    val liveDist: Float? =
        if (tilt > 3f) camH / tan(Math.toRadians(tilt.toDouble())).toFloat() else null

    fun reset() { step = 0; result = null }

    Column(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp).glass(24.dp).padding(14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("المسافة", kind == 0) { kind = 0; reset() }
            Chip("الارتفاع", kind == 1) { kind = 1; reset() }
            Chip("معايرة", kind == 2) { kind = 2; reset() }
        }
        if (kind < 2) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("ارتفاع الهاتف", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                Chip("-1") { onCamH((camH - 1).coerceAtLeast(30)); reset() }
                Text("$camH سم", color = CYAN, fontWeight = FontWeight.Bold)
                Chip("+1") { onCamH((camH + 1).coerceAtMost(250)); reset() }
            }
        } else {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("المسافة المعروفة", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                Chip("-10") { knownD = (knownD - 10).coerceAtLeast(50); reset() }
                Text("$knownD سم", color = CYAN, fontWeight = FontWeight.Bold)
                Chip("+10") { knownD = (knownD + 10).coerceAtMost(500); reset() }
            }
        }

        val msg = when {
            result != null -> result!!
            kind == 2 -> "ضع علامة على الأرض على بُعد $knownD سم أفقياً منك، ثم وجّه المركز نحوها"
            kind == 0 -> if (liveDist != null) "المسافة ≈ ${liveDist.toInt()} سم" else "وجّه المركز نحو الأرض عند قاعدة الجسم"
            step == 0 -> if (liveDist != null) "القاعدة على بُعد ≈ ${liveDist.toInt()} سم" else "وجّه المركز إلى قاعدة الجسم"
            else -> "الآن وجّه المركز إلى أعلى الجسم"
        }
        Text(msg, color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        Text("زاوية الميل: ${"%.1f".format(tilt)}°", color = Color(0x99FFFFFF), fontSize = 11.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            if (result != null) {
                Chip("قياس جديد", true) { reset() }
            } else if (kind == 2) {
                Chip("معايرة الآن", true) {
                    if (tilt > 5f) {
                        val h = (knownD * tan(Math.toRadians(tilt.toDouble()))).roundToInt().coerceIn(30, 250)
                        onCamH(h)
                        result = "تمت المعايرة: ارتفاع الهاتف = $h سم"
                    }
                }
            } else if (kind == 0) {
                Chip("تثبيت القياس", true) {
                    if (liveDist != null) result = "المسافة ≈ ${liveDist.toInt()} سم (${"%.2f".format(liveDist / 100f)} م)"
                }
            } else if (step == 0) {
                Chip("تثبيت القاعدة", true) { if (liveDist != null) { baseDist = liveDist; step = 1 } }
            } else {
                Chip("تثبيت القمة", true) {
                    val h = camH - baseDist * tan(Math.toRadians(tilt.toDouble())).toFloat()
                    result = "الارتفاع ≈ ${h.toInt()} سم (${"%.2f".format(h / 100f)} م)"
                }
            }
        }
        Text(
            "للدقة: عاير أولاً من تبويب «معايرة» (الدقة التقريبية بعدها ±2 إلى 4%). أمسك الهاتف رأسياً وثابتاً.",
            color = Color(0x99FFFFFF), fontSize = 11.sp, textAlign = TextAlign.Center
        )
    }
}
