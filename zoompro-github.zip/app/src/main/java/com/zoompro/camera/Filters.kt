package com.zoompro.camera

import android.graphics.ColorMatrix

/** فلتر لوني. matrix = null يعني بدون فلتر. */
data class CamFilter(val name: String, val night: Boolean, val matrix: ColorMatrix?)

private fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

private fun bc(b: Float, c: Float): ColorMatrix {
    val t = (1f - c) * 128f + b
    return ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f))
}

private fun tint(r: Float, g: Float, b: Float) = ColorMatrix(floatArrayOf(
    r, 0f, 0f, 0f, 0f,
    0f, g, 0f, 0f, 0f,
    0f, 0f, b, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

private fun mix(vararg m: ColorMatrix) = ColorMatrix().apply { m.forEach { postConcat(it) } }

private val nightVision = ColorMatrix(floatArrayOf(
    0f, 0f, 0f, 0f, 0f,
    0.45f, 0.9f, 0.17f, 0f, 35f,
    0f, 0f, 0f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

val FILTERS = listOf(
    CamFilter("طبيعي", false, null),
    CamFilter("حيوي", false, mix(sat(1.4f), bc(0f, 1.1f))),
    CamFilter("دافئ", false, mix(tint(1.1f, 1f, 0.88f), sat(1.1f))),
    CamFilter("بارد", false, tint(0.9f, 1f, 1.12f)),
    CamFilter("سينمائي", false, mix(sat(0.85f), bc(-6f, 1.2f), tint(1.04f, 1f, 0.96f))),
    CamFilter("أبيض وأسود", false, mix(sat(0f), bc(0f, 1.15f))),
    CamFilter("كلاسيكي", false, mix(sat(0.7f), tint(1.1f, 1f, 0.85f), bc(10f, 0.92f))),
    CamFilter("ليل صافٍ", true, mix(bc(35f, 1.15f), sat(1.1f))),
    CamFilter("رؤية ليلية", true, nightVision),
    CamFilter("تعزيز الضوء", true, bc(55f, 1.25f)),
    CamFilter("ضوء القمر", true, mix(tint(0.88f, 0.98f, 1.15f), bc(25f, 1.1f), sat(0.85f))),
    CamFilter("نيون", true, mix(sat(1.8f), bc(10f, 1.25f))),
)

/** يمزج الفلتر مع الصورة الأصلية حسب القوة (0..1). */
fun CamFilter.blended(strength: Float): ColorMatrix? {
    val m = matrix ?: return null
    val a = m.array
    val out = FloatArray(20) { i ->
        val id = if (i == 0 || i == 6 || i == 12 || i == 18) 1f else 0f
        id + (a[i] - id) * strength
    }
    return ColorMatrix(out)
}
