package com.zoompro.camera

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.min

/** حدة خفيفة (Unsharp Mask بمرشح 3x3) لتحسين الصورة المكبّرة برمجياً. */
fun sharpen(src: Bitmap, amount: Float): Bitmap {
    val w = src.width
    val h = src.height
    val px = IntArray(w * h)
    src.getPixels(px, 0, w, 0, 0, w, h)
    val out = px.copyOf()
    for (y in 1 until h - 1) {
        val row = y * w
        for (x in 1 until w - 1) {
            val i = row + x
            var sr = 0; var sg = 0; var sb = 0
            for (dy in -1..1) {
                for (dx in -1..1) {
                    val p = px[i + dy * w + dx]
                    sr += (p shr 16) and 255
                    sg += (p shr 8) and 255
                    sb += p and 255
                }
            }
            val c = px[i]
            val cr = (c shr 16) and 255
            val cg = (c shr 8) and 255
            val cb = c and 255
            val nr = (cr + amount * (cr - sr / 9f)).toInt().coerceIn(0, 255)
            val ng = (cg + amount * (cg - sg / 9f)).toInt().coerceIn(0, 255)
            val nb = (cb + amount * (cb - sb / 9f)).toInt().coerceIn(0, 255)
            out[i] = (0xFF shl 24) or (nr shl 16) or (ng shl 8) or nb
        }
    }
    return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
}

/**
 * تكبير برمجي فوق حد عدسة الهاتف: قص المركز ثم رفع الحجم ثم شحذ.
 * soft = نسبة التكبير الزائدة (zoom / أقصى زوم للعتاد). يعيد src نفسه إن لم يلزم.
 */
fun boostZoom(src: Bitmap, soft: Float): Bitmap {
    if (soft <= 1.01f) return src
    val w2 = (src.width / soft).toInt().coerceAtLeast(16)
    val h2 = (src.height / soft).toInt().coerceAtLeast(16)
    val x = (src.width - w2) / 2
    val y = (src.height - h2) / 2
    val cropped = Bitmap.createBitmap(src, x, y, w2, h2)
    val k = min(1f, 3000f / max(src.width, src.height))
    val tw = (src.width * k).toInt()
    val th = (src.height * k).toInt()
    val scaled = Bitmap.createScaledBitmap(cropped, tw, th, true)
    if (cropped !== scaled) cropped.recycle()
    val out = sharpen(scaled, 0.6f)
    scaled.recycle()
    return out
}
