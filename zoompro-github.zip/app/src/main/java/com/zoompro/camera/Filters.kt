package com.zoompro.camera

import android.graphics.ColorMatrix

data class CamFilter(val name: String, val night: Boolean, val matrix: ColorMatrix?)

data class Adjust(val contrast: Float = 1f, val saturation: Float = 1f, val warmth: Float = 0f) {
    val isDefault get() = contrast == 1f && saturation == 1f && warmth == 0f
}

internal fun sat(s: Float) = ColorMatrix().apply { setSaturation(s) }

internal fun bc(b: Float, c: Float): ColorMatrix {
    val t = (1f - c) * 128f + b
    return ColorMatrix(floatArrayOf(
        c, 0f, 0f, 0f, t,
        0f, c, 0f, 0f, t,
        0f, 0f, c, 0f, t,
        0f, 0f, 0f, 1f, 0f))
}

internal fun tint(r: Float, g: Float, b: Float) = ColorMatrix(floatArrayOf(
    r, 0f, 0f, 0f, 0f,
    0f, g, 0f, 0f, 0f,
    0f, 0f, b, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

internal fun mix(vararg m: ColorMatrix) = ColorMatrix().apply { m.forEach { postConcat(it) } }

private val nightVision = ColorMatrix(floatArrayOf(
    0f, 0f, 0f, 0f, 0f,
    0.45f, 0.9f, 0.17f, 0f, 35f,
    0f, 0f, 0f, 0f, 0f,
    0f, 0f, 0f, 1f, 0f))

val FILTERS = listOf(
    CamFilter("طبيعي", false, null),
    CamFilter("حيوي", false, mix(sat(1.4f), bc(0f, 1.1f))),
    CamFilter("دافئ", false, mix(tint(1.1f, 1f, 0.88f), sat(1.1f))),
    CamFilter("بارد", false, tint(0.9f, 1f, 1.12f)),
    CamFilter("سينمائي", false, mix(sat(0.85f), bc(-6f, 1.2f), tint(1.04f, 1f, 0.96f))),
    CamFilter("أبيض وأسود", false, mix(sat(0f), bc(0f, 1.15f))),
    CamFilter("كلاسيكي", false, mix(sat(0.7f), tint(1.1f, 1f, 0.85f), bc(10f, 0.92f))),
    CamFilter("توهج البورتريه", false, mix(tint(1.06f, 1f, 0.97f), bc(12f, 0.95f), sat(1.05f))),
    CamFilter("HDR بوب", false, mix(bc(-4f, 1.3f), sat(1.35f))),
    CamFilter("ليل صافٍ", true, mix(bc(35f, 1.15f), sat(1.1f))),
    CamFilter("رؤية ليلية", true, nightVision),
    CamFilter("تعزيز الضوء", true, bc(55f, 1.25f)),
    CamFilter("ضوء القمر", true, mix(tint(0.88f, 0.98f, 1.15f), bc(25f, 1.1f), sat(0.85f))),
    CamFilter("نيون", true, mix(sat(1.8f), bc(10f, 1.25f))),
)

fun CamFilter.blended(strength: Float): ColorMatrix? {
    val m = matrix ?: return null
    val a = m.array
    val out = FloatArray(20) { i ->
        val id = if (i == 0 || i == 6 || i == 12 || i == 18) 1f else 0f
        id + (a[i] - id) * strength
    }
    return ColorMatrix(out)
}

/** الفلتر + قوته + الضبط اليدوي (تباين/تشبع/حرارة). null = بدون أي تغيير. */
fun buildMatrix(f: CamFilter, strength: Float, a: Adjust): ColorMatrix? {
    val base = f.blended(strength)
    if (base == null && a.isDefault) return null
    val m = base ?: ColorMatrix()
    if (!a.isDefault) {
        m.postConcat(bc(0f, a.contrast))
        m.postConcat(sat(a.saturation))
        m.postConcat(tint(1f + a.warmth, 1f, 1f - a.warmth))
    }
    return m
}
