package com.zoompro.camera

import android.Manifest
import android.content.ContentValues
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas as AndroidCanvas
import android.graphics.ColorMatrixColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Size
import android.view.View
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.FocusMeteringAction
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.resolutionselector.AspectRatioStrategy
import androidx.camera.core.resolutionselector.ResolutionSelector
import androidx.camera.core.resolutionselector.ResolutionStrategy
import androidx.camera.extensions.ExtensionMode
import androidx.camera.extensions.ExtensionsManager
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleOwner
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.roundToInt

private enum class Mode(val label: String) { PHOTO("صورة"), NIGHT("ليلي"), MEASURE("قياس") }

private val previewSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .build()

// نلتقط بحوالي 12 ميجابكسل لتفادي نفاد الذاكرة عند المعالجة
private val captureSelector = ResolutionSelector.Builder()
    .setAspectRatioStrategy(AspectRatioStrategy.RATIO_4_3_FALLBACK_AUTO_STRATEGY)
    .setResolutionStrategy(
        ResolutionStrategy(Size(4000, 3000), ResolutionStrategy.FALLBACK_RULE_CLOSEST_LOWER_THEN_HIGHER)
    ).build()

private fun toast(ctx: Context, msg: String) {
    Handler(Looper.getMainLooper()).post { Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show() }
}

private fun newImageValues() = ContentValues().apply {
    put(MediaStore.Images.Media.DISPLAY_NAME,
        "ZoomPro_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()))
    put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
    put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/ZoomPro")
}

private fun saveBitmap(ctx: Context, bmp: Bitmap) {
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues())
        ?: error("MediaStore insert failed")
    ctx.contentResolver.openOutputStream(uri)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, 95, it) }
}

private fun applyMatrix(src: Bitmap, m: android.graphics.ColorMatrix): Bitmap {
    val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
    AndroidCanvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(m) })
    return out
}

private fun uprightBitmap(image: ImageProxy): Bitmap {
    val src = image.toBitmap()
    val rot = Matrix().apply { postRotate(image.imageInfo.rotationDegrees.toFloat()) }
    val up = Bitmap.createBitmap(src, 0, 0, src.width, src.height, rot, true)
    if (up !== src) src.recycle()
    return up
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 12.sp, modifier = Modifier.width(76.dp))
        Slider(value = value, onValueChange = onChange, valueRange = range, modifier = Modifier.weight(1f))
    }
}

@Composable
fun CameraScreen() {
    val ctx = LocalContext.current
    val owner = ctx as LifecycleOwner
    val scope = rememberCoroutineScope()

    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(
            Modifier.fillMaxSize().background(BG0).padding(32.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("يحتاج التطبيق إلى إذن الكاميرا ليعمل.", color = Color.White, textAlign = TextAlign.Center)
            Spacer(Modifier.height(16.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("منح الإذن") }
        }
        return
    }

    val previewView = remember {
        PreviewView(ctx).apply {
            implementationMode = PreviewView.ImplementationMode.COMPATIBLE
            scaleType = PreviewView.ScaleType.FIT_CENTER
        }
    }
    val executor = remember { Executors.newSingleThreadExecutor() }

    var mode by remember { mutableStateOf(Mode.PHOTO) }
    var lens by remember { mutableIntStateOf(CameraSelector.LENS_FACING_BACK) }
    var camera by remember { mutableStateOf<Camera?>(null) }
    var maxZoom by remember { mutableFloatStateOf(1f) }
    var zoom by remember { mutableFloatStateOf(1f) }
    var fIdx by remember { mutableIntStateOf(0) }
    var strength by remember { mutableFloatStateOf(1f) }
    var adjust by remember { mutableStateOf(Adjust()) }
    var expRange by remember { mutableStateOf(0..0) }
    var exp by remember { mutableFloatStateOf(0.5f) }
    var flash by remember { mutableStateOf(false) }
    var grid by remember { mutableStateOf(false) }
    var timer by remember { mutableIntStateOf(0) }
    var countdown by remember { mutableIntStateOf(0) }
    var panel by remember { mutableStateOf(false) }
    var ring by remember { mutableStateOf<Offset?>(null) }
    var busy by remember { mutableStateOf(false) }
    var progress by remember { mutableStateOf("") }
    var hwMax by remember { mutableFloatStateOf(1f) }
    var camH by remember { mutableIntStateOf(130) }
    var ext by remember { mutableIntStateOf(ExtensionMode.NONE) }
    var extHdr by remember { mutableStateOf(false) }
    var extNight by remember { mutableStateOf(false) }

    val tilt = rememberTilt(mode == Mode.MEASURE)
    val capture = remember(lens) { ImageCapture.Builder().setResolutionSelector(captureSelector).build() }

    fun bindCamera(provider: ProcessCameraProvider, sel: CameraSelector) {
        val preview = Preview.Builder().setResolutionSelector(previewSelector).build()
            .also { it.setSurfaceProvider(previewView.surfaceProvider) }
        provider.unbindAll()
        val cam = provider.bindToLifecycle(owner, sel, preview, capture)
        camera = cam
        hwMax = (cam.cameraInfo.zoomState.value?.maxZoomRatio ?: 1f).coerceAtLeast(1f)
        maxZoom = (hwMax * 3f).coerceAtMost(30f)   // ما فوق حد العتاد = تكبير برمجي
        zoom = 1f
        val r = cam.cameraInfo.exposureState.exposureCompensationRange
        expRange = r.lower..r.upper
        exp = 0.5f
    }

    DisposableEffect(lens, ext) {
        val future = ProcessCameraProvider.getInstance(ctx)
        future.addListener({
            try {
                val provider = future.get()
                val base = CameraSelector.Builder().requireLensFacing(lens).build()
                val extFuture = ExtensionsManager.getInstanceAsync(ctx, provider)
                extFuture.addListener({
                    try {
                        val mgr = extFuture.get()
                        extHdr = mgr.isExtensionAvailable(base, ExtensionMode.HDR)
                        extNight = mgr.isExtensionAvailable(base, ExtensionMode.NIGHT)
                        val sel = if (ext != ExtensionMode.NONE && mgr.isExtensionAvailable(base, ext))
                            mgr.getExtensionEnabledCameraSelector(base, ext) else base
                        try {
                            bindCamera(provider, sel)
                        } catch (e: Exception) {
                            if (sel !== base) { ext = ExtensionMode.NONE; toast(ctx, "الوضع الأصلي غير مدعوم هنا") }
                            else throw e
                        }
                    } catch (e: Exception) {
                        toast(ctx, "تعذر تشغيل الكاميرا: ${e.message}")
                    }
                }, ContextCompat.getMainExecutor(ctx))
            } catch (e: Exception) {
                toast(ctx, "تعذر تشغيل الكاميرا: ${e.message}")
            }
        }, ContextCompat.getMainExecutor(ctx))
        onDispose { if (future.isDone) runCatching { future.get().unbindAll() } }
    }

    fun setZ(v: Float) {
        val z = v.coerceIn(1f, maxZoom)
        zoom = z
        camera?.cameraControl?.setZoomRatio(minOf(z, hwMax))
    }

    fun setExp(f: Float) {
        exp = f
        val span = expRange.last - expRange.first
        if (span > 0) camera?.cameraControl?.setExposureCompensationIndex(expRange.first + (f * span).roundToInt())
    }

    LaunchedEffect(mode, camera) {
        if (mode == Mode.NIGHT) {
            if (!FILTERS[fIdx].night) fIdx = FILTERS.indexOfFirst { it.name == "ليل صافٍ" }
            setExp(0.85f)
        } else setExp(0.5f)
    }

    fun shootPhoto() {
        capture.flashMode = if (flash) ImageCapture.FLASH_MODE_ON else ImageCapture.FLASH_MODE_OFF
        val m = buildMatrix(FILTERS[fIdx], strength, adjust)
        val soft = max(1f, zoom / hwMax)
        busy = true
        if (m == null && soft <= 1.01f) {
            val opts = ImageCapture.OutputFileOptions.Builder(
                ctx.contentResolver, MediaStore.Images.Media.EXTERNAL_CONTENT_URI, newImageValues()).build()
            capture.takePicture(opts, executor, object : ImageCapture.OnImageSavedCallback {
                override fun onImageSaved(output: ImageCapture.OutputFileResults) { busy = false; toast(ctx, "تم الحفظ") }
                override fun onError(e: ImageCaptureException) { busy = false; toast(ctx, "تعذر الحفظ: ${e.message}") }
            })
        } else {
            capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val up = uprightBitmap(image)
                        val boosted = boostZoom(up, soft)
                        if (boosted !== up) up.recycle()
                        val out = if (m != null) applyMatrix(boosted, m).also { boosted.recycle() } else boosted
                        saveBitmap(ctx, out)
                        out.recycle()
                        toast(ctx, "تم الحفظ")
                    } catch (e: Throwable) {
                        toast(ctx, "تعذر الحفظ: ${e.message}")
                    } finally {
                        image.close()
                        busy = false
                    }
                }
                override fun onError(e: ImageCaptureException) { busy = false; toast(ctx, "تعذر الالتقاط: ${e.message}") }
            })
        }
    }

    fun finishNight(stacker: NightStacker) {
        try {
            val stackedRaw = stacker.result()
            val stacked = boostZoom(stackedRaw, max(1f, zoom / hwMax))
            if (stacked !== stackedRaw) stackedRaw.recycle()
            val m = buildMatrix(FILTERS[fIdx], strength, adjust)
            val out = if (m != null) applyMatrix(stacked, m).also { stacked.recycle() } else stacked
            saveBitmap(ctx, out)
            out.recycle()
            toast(ctx, "تم حفظ الصورة الليلية")
        } catch (e: Throwable) {
            toast(ctx, "تعذر الحفظ: ${e.message}")
        } finally {
            busy = false
            progress = ""
        }
    }

    fun shootNight() {
        busy = true
        capture.flashMode = ImageCapture.FLASH_MODE_OFF
        val stacker = NightStacker()
        val total = 6
        fun next(i: Int) {
            progress = "ثبّت الهاتف... $i/$total"
            capture.takePicture(executor, object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    var ok = true
                    try {
                        val up = uprightBitmap(image)
                        stacker.add(up)
                        up.recycle()
                    } catch (e: Throwable) {
                        ok = false
                        toast(ctx, "تعذر المعالجة: ${e.message}")
                    } finally {
                        image.close()
                    }
                    if (!ok) { busy = false; progress = ""; return }
                    if (i < total) next(i + 1) else finishNight(stacker)
                }
                override fun onError(e: ImageCaptureException) {
                    busy = false; progress = ""; toast(ctx, "تعذر الالتقاط: ${e.message}")
                }
            })
        }
        next(1)
    }

    fun onShutter() {
        if (busy || countdown > 0) return
        scope.launch {
            if (timer > 0) {
                for (s in timer downTo 1) { countdown = s; delay(1000) }
                countdown = 0
            }
            if (mode == Mode.NIGHT) shootNight() else shootPhoto()
        }
    }

    LaunchedEffect(ring) { if (ring != null) { delay(900); ring = null } }

    Column(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(BG0, BG1)))
            .statusBarsPadding().navigationBarsPadding()
    ) {
        // الشريط العلوي
        Row(
            Modifier.fillMaxWidth().height(52.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Chip("فلاش", flash) { flash = !flash }
            Chip("شبكة", grid) { grid = !grid }
            Chip(if (timer == 0) "مؤقت" else "${timer}ث", timer > 0) {
                timer = when (timer) { 0 -> 3; 3 -> 10; else -> 0 }
            }
            Chip("قلب") {
                lens = if (lens == CameraSelector.LENS_FACING_BACK)
                    CameraSelector.LENS_FACING_FRONT else CameraSelector.LENS_FACING_BACK
            }
        }

        // المعاينة
        Box(Modifier.fillMaxWidth().aspectRatio(3f / 4f)) {
            Box(Modifier.fillMaxSize().clipToBounds()) {
                AndroidView(
                    factory = { previewView },
                    modifier = Modifier.fillMaxSize().graphicsLayer {
                        val sc = max(1f, zoom / hwMax)
                        scaleX = sc
                        scaleY = sc
                    },
                    update = { v ->
                        val m = buildMatrix(FILTERS[fIdx], strength, adjust)
                        val paint = m?.let { Paint().apply { colorFilter = ColorMatrixColorFilter(it) } }
                        v.setLayerType(View.LAYER_TYPE_HARDWARE, paint)
                    }
                )
            }
            if (grid) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = Color(0x66FFFFFF)
                    for (i in 1..2) {
                        drawLine(c, Offset(size.width * i / 3f, 0f), Offset(size.width * i / 3f, size.height), 2f)
                        drawLine(c, Offset(0f, size.height * i / 3f), Offset(size.width, size.height * i / 3f), 2f)
                    }
                }
            }
            if (mode == Mode.MEASURE) {
                Canvas(Modifier.fillMaxSize()) {
                    val c = center
                    drawCircle(CYAN, 26f, c, style = Stroke(3f))
                    drawLine(CYAN, Offset(c.x - 70f, c.y), Offset(c.x + 70f, c.y), 3f)
                    drawLine(CYAN, Offset(c.x, c.y - 70f), Offset(c.x, c.y + 70f), 3f)
                }
            }
            Box(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, _, g, _ -> if (g != 1f) setZ(zoom * g) }
                    }
                    .pointerInput(Unit) {
                        detectTapGestures { o ->
                            val sc = max(1f, zoom / hwMax)
                            val cx = size.width / 2f
                            val cy = size.height / 2f
                            val pt = previewView.meteringPointFactory.createPoint(cx + (o.x - cx) / sc, cy + (o.y - cy) / sc)
                            camera?.cameraControl?.startFocusAndMetering(FocusMeteringAction.Builder(pt).build())
                            ring = o
                        }
                    }
            )
            ring?.let { p ->
                Box(
                    Modifier
                        .offset { IntOffset((p.x - 30.dp.toPx()).roundToInt(), (p.y - 30.dp.toPx()).roundToInt()) }
                        .size(60.dp).border(2.dp, CYAN, CircleShape)
                )
            }
            Text(
                "%.1fx".format(zoom) + if (zoom > hwMax + 0.05f) " (برمجي)" else "", color = Color.White, fontSize = 15.sp,
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 8.dp).glass(12.dp)
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            )
            if (countdown > 0) {
                Text("$countdown", color = Color.White, fontSize = 96.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.Center))
            }
            if (progress.isNotEmpty()) {
                Text(progress, color = Color.White, fontSize = 14.sp,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(10.dp).glass(14.dp)
                        .padding(horizontal = 14.dp, vertical = 6.dp))
            }
            Box(Modifier.fillMaxSize().border(1.5.dp, BRAND, RectangleShape))
            if (panel) {
                Column(
                    Modifier.align(Alignment.BottomCenter).fillMaxWidth()
                        .background(Color(0xDD0B0A14)).padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    if (maxZoom > 1.01f) LabeledSlider("الزوم", zoom, 1f..maxZoom) { setZ(it) }
                    LabeledSlider("قوة الفلتر", strength, 0f..1f) { strength = it }
                    if (expRange.last > expRange.first) LabeledSlider("السطوع", exp, 0f..1f) { setExp(it) }
                    LabeledSlider("التباين", adjust.contrast, 0.6f..1.6f) { adjust = adjust.copy(contrast = it) }
                    LabeledSlider("التشبع", adjust.saturation, 0f..2f) { adjust = adjust.copy(saturation = it) }
                    LabeledSlider("الحرارة", adjust.warmth, -0.2f..0.2f) { adjust = adjust.copy(warmth = it) }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        Chip("إعادة الضبط") { adjust = Adjust(); strength = 1f }
                    }
                }
            }
        }

        Spacer(Modifier.weight(1f))

        // شريط الأوضاع
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), horizontalArrangement = Arrangement.Center) {
            Mode.values().forEach { m ->
                Text(
                    m.label,
                    color = if (mode == m) Color.White else Color(0x99FFFFFF),
                    fontWeight = if (mode == m) FontWeight.Bold else FontWeight.Normal,
                    fontSize = 15.sp,
                    modifier = Modifier.padding(horizontal = 6.dp).clip(RoundedCornerShape(16.dp))
                        .then(if (mode == m) Modifier.background(BRAND) else Modifier)
                        .clickable { mode = m }.padding(horizontal = 18.dp, vertical = 6.dp)
                )
            }
        }

        if (mode == Mode.MEASURE) {
            MeasurePanel(tilt.floatValue, camH) { camH = it }
            Spacer(Modifier.height(6.dp))
        } else {
            Row(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
            ) {
                (listOf(1f, 2f, 3f, 5f, 10f, 20f, 30f).filter { it <= maxZoom }).forEach { z ->
                    Chip("${z.toInt()}x", abs(zoom - z) < 0.05f) { setZ(z) }
                }
                if (extHdr) Chip("HDR أصلي", ext == ExtensionMode.HDR) {
                    ext = if (ext == ExtensionMode.HDR) ExtensionMode.NONE else ExtensionMode.HDR
                }
                if (extNight) Chip("ليل أصلي", ext == ExtensionMode.NIGHT, true) {
                    ext = if (ext == ExtensionMode.NIGHT) ExtensionMode.NONE else ExtensionMode.NIGHT
                }
            }
            LazyRow(
                Modifier.fillMaxWidth().padding(vertical = 4.dp),
                contentPadding = PaddingValues(horizontal = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(FILTERS.size) { i ->
                    Chip(FILTERS[i].name, fIdx == i, FILTERS[i].night) { fIdx = i }
                }
            }
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Chip(if (panel) "إخفاء" else "ضبط", panel) { panel = !panel }
                ShutterButton(busy) { onShutter() }
                Spacer(Modifier.width(64.dp))
            }
        }
    }
}
