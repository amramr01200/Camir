# R8 rules: CameraX ships its own consumer rules.
