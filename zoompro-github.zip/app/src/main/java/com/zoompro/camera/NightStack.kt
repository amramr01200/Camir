package com.zoompro.camera

import android.graphics.Bitmap
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.roundToInt

/** يدمج عدة لقطات بمتوسط (يقلل الضوضاء) ثم يرفع الظلال بمنحنى جاما. */
class NightStacker(private val longSide: Int = 2000) {
    private var w = 0
    private var h = 0
    private var n = 0
    private var sr: IntArray? = null
    private var sg: IntArray? = null
    private var sb: IntArray? = null

    fun add(upright: Bitmap) {
        if (sr == null) {
            val s = longSide.toFloat() / max(upright.width, upright.height)
            w = (upright.width * s).roundToInt()
            h = (upright.height * s).roundToInt()
            sr = IntArray(w * h); sg = IntArray(w * h); sb = IntArray(w * h)
        }
        val scaled = Bitmap.createScaledBitmap(upright, w, h, true)
        val px = IntArray(w * h)
        scaled.getPixels(px, 0, w, 0, 0, w, h)
        if (scaled !== upright) scaled.recycle()
        val r = sr!!; val g = sg!!; val b = sb!!
        for (i in px.indices) {
            val p = px[i]
            r[i] += (p shr 16) and 255
            g[i] += (p shr 8) and 255
            b[i] += p and 255
        }
        n++
    }

    fun result(gamma: Float = 0.62f): Bitmap {
        val lut = IntArray(256) { (255.0 * (it / 255.0).pow(gamma.toDouble())).roundToInt().coerceIn(0, 255) }
        val r = sr!!; val g = sg!!; val b = sb!!
        val out = IntArray(w * h)
        for (i in out.indices) {
            out[i] = (0xFF shl 24) or (lut[r[i] / n] shl 16) or (lut[g[i] / n] shl 8) or lut[b[i] / n]
        }
        return Bitmap.createBitmap(out, w, h, Bitmap.Config.ARGB_8888)
    }
}
